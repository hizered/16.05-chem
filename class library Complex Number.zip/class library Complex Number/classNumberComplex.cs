﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class_library_Complex_Number
{
    /// <summary>
    /// библиотека класса комплексного числа
    /// </summary>
    public class classNumberComplex
    {
        private double x;
        private double y;

        public double X { get { return x; } set { x = value; } }
        public double Y { get { return y; } set { y = value; } }
        public classNumberComplex()
        {
            x = 0;
            y = 0;
        }
        public classNumberComplex(double a, double b) 
        {
            x = a;
            y = b;
        }
        public override string ToString()
        {
            return $"{x}+{y}*i";
        }
        public string additiom(classNumberComplex complex2)
        {
            classNumberComplex c3 = new classNumberComplex();
            c3.x = x + complex2.x;
            c3.y = y + complex2.y;
            return $"{x}+{y}*i";
        }
        public string subtraction(classNumberComplex complex2)
        {
            classNumberComplex c3 = new classNumberComplex();
            c3.x = x - complex2.x;
            c3.y = y - complex2.y;
            return $"{x}+{y}*i";

        }

        public string multiplication(classNumberComplex complex1, classNumberComplex complex2)
        {
            classNumberComplex c3 = new classNumberComplex();
            
            return c3.ToString();
        }
        public string Segmentation(classNumberComplex complex1, classNumberComplex complex2)
        {
            classNumberComplex c3 = new classNumberComplex();

            return c3.ToString();
        }

    }
}
